# MBU

Package mit allgemeinen Assets für Unity-Projekte.
